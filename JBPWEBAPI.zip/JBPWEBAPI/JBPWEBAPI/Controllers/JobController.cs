﻿using JBPWEBAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace JBPWEBAPI.Controllers
{
  //  [Route("api/[controller]")]
    [ApiController]
    public class JobController : ControllerBase
    {
        private readonly string connectionString;

        public JobController( IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("DefaultConnection");
        }

       
        [HttpGet("jobs")]
        public IActionResult GetAllJobpostngs()
        {
            try
            {
                List<Jobposts> jobposts = GetAllJobPostings();


                return Ok(jobposts);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        private List<Jobposts> GetAllJobPostings()
        {
            List<Jobposts> jobposts = new List<Jobposts>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM jobposts";
                SqlCommand command = new SqlCommand(query, connection);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();


                while (reader.Read())
                {
                    Jobposts job = new Jobposts()
                    {
                        JobID = Convert.ToInt32(reader["JobID"]),
                        Title = reader["Title"].ToString(),
                        Skills = reader["Skills"].ToString(),
                        Company = reader["Company"].ToString(),
                        Location = reader["Location"].ToString(),
                        Employment_Type = reader["Employment_Type"].ToString(),
                        Salary = Convert.ToDecimal(reader["Salary"]),
                        Application_Deadline = Convert.ToDateTime(reader["Application_Deadline"])
                    };

                    jobposts.Add(job);
                }
                reader.Close();

                return jobposts;
            }
        }
        [HttpPost("Jobs")]
        public void AddJobPosting(Jobposts jobposts)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO jobposts (JobID, Title, Skills, Company, Location, Employment_Type, Salary, Application_Deadline) " +
               "VALUES (@JobID, @Title, @Skills, @Company, @Location, @Employment_Type, @Salary, @Application_Deadline)";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@JobID", jobposts.JobID);
                command.Parameters.AddWithValue("@Title", jobposts.Title);
                command.Parameters.AddWithValue("@Skills", jobposts.Skills);
                command.Parameters.AddWithValue("@Company", jobposts.Company);
                command.Parameters.AddWithValue("@Location", jobposts.Location);
                command.Parameters.AddWithValue("@Employment_Type", jobposts.Employment_Type);
                command.Parameters.AddWithValue("@Salary", jobposts.Salary);
                command.Parameters.AddWithValue("@Application_Deadline", jobposts.Application_Deadline);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
        [HttpPut("jobs/{id}")]
        public IActionResult UpdateJobPosting(int id, Jobposts jobposts)
        {
            try
            {
                var existingJobPost = GetJobPostingById(id);
                if (existingJobPost == null)
                    return NotFound("Job posting not found");

                if (id != jobposts.JobID)
                    return BadRequest("Invalid job ID");

                UpdateJobPostingById(jobposts);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        private Jobposts GetJobPostingById(int id)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM JobPosts WHERE JobID = @JobID";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@JobID", id);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    Jobposts jobposts = new Jobposts()
                    {
                        JobID = Convert.ToInt32(reader["JobID"]),
                        Title = reader["Title"].ToString(),
                        Skills = reader["Skills"].ToString(),
                        Company = reader["Company"].ToString(),
                        Location = reader["Location"].ToString(),
                        Employment_Type = reader["Employment_Type"].ToString(),
                        Salary = Convert.ToDecimal(reader["Salary"]),
                        Application_Deadline = Convert.ToDateTime(reader["Application_Deadline"])
                    };

                    reader.Close();
                    return jobposts;
                }

                reader.Close();
                return null;
            }
        }

        private void UpdateJobPostingById(Jobposts jobposts)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE jobposts SET Title = @Title, Skills = @Skills, Company = @Company, " +
                               "Location = @Location, Employment_Type = @Employment_Type, Salary = @Salary, " +
                               "Application_Deadline = @Application_Deadline WHERE JobID = @JobID";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@JobID", jobposts.JobID);
                command.Parameters.AddWithValue("@Title", jobposts.Title);
                command.Parameters.AddWithValue("@Skills", jobposts.Skills);
                command.Parameters.AddWithValue("@Company", jobposts.Company);
                command.Parameters.AddWithValue("@Location", jobposts.Location);
                command.Parameters.AddWithValue("@Employment_Type", jobposts.Employment_Type);
                command.Parameters.AddWithValue("@Salary", jobposts.Salary);
                command.Parameters.AddWithValue("@Application_Deadline", jobposts.Application_Deadline);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
        [HttpDelete("jobs/{id}")]
        public IActionResult DeleteJobPosting(int id)
        {
            try
            {
                var existingJobPost = GetJobPostingById(id);
                if (existingJobPost == null)
                    return NotFound("Job posting not found");

                DeleteJobPostingById(id);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        private void DeleteJobPostingById(int id)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM jobPosts WHERE JobID = @JobID";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@JobID", id);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        [HttpGet("jobs/{id}")]
        public IActionResult GetSingleJobPostingById(int id)
        {
            try
            {
                var jobPost = GetJobPostingByIdFromDatabase(id);
                if (jobPost == null)
                    return NotFound("Job posting not found");

                return Ok(jobPost);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        private Jobposts GetJobPostingByIdFromDatabase(int id)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM jobPosts WHERE JobID = @JobID";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@JobID", id);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    Jobposts jobPost = new Jobposts()
                    {
                        JobID = Convert.ToInt32(reader["JobID"]),
                        Title = reader["Title"].ToString(),
                        Skills = reader["Skills"].ToString(),
                        Company = reader["Company"].ToString(),
                        Location = reader["Location"].ToString(),
                        Employment_Type = reader["Employment_Type"].ToString(),
                        Salary = Convert.ToDecimal(reader["Salary"]),
                        Application_Deadline = Convert.ToDateTime(reader["Application_Deadline"])
                    };

                    reader.Close();
                    return jobPost;
                }

                reader.Close();
                return null;
            }
        }


    }
}

