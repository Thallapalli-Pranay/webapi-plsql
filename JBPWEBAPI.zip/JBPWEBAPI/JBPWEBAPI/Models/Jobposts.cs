﻿namespace JBPWEBAPI.Models
{
    public class Jobposts
    { 
            public int JobID { get; set; }
            public string Title { get; set; }
            public string Skills { get; set; }
            public string Company { get; set; }
            public string Location { get; set; }
            public string Employment_Type { get; set; }
            public decimal Salary { get; set; }
            public DateTime Application_Deadline { get; set; }
        }

    }

